package com.example.locationfinder;


import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    private EditText addressInput, latitudeInput, longitudeInput;
    private Button addButton, queryButton, updateButton, deleteButton;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // intalizing the views
        addressInput = findViewById(R.id.addressInput);
        latitudeInput = findViewById(R.id.latitudeInput);
        longitudeInput = findViewById(R.id.longitudeInput);
        addButton = findViewById(R.id.addButton);
        updateButton = findViewById(R.id.updateButton);
        deleteButton = findViewById(R.id.deleteButton);

        // Initializing Database Helper
        databaseHelper = new DatabaseHelper(this);
        // Setting up the Add Button OnClickListener
        addButton.setOnClickListener(view -> {
            String address = addressInput.getText().toString();
            double latitude = Double.parseDouble(latitudeInput.getText().toString());
            double longitude = Double.parseDouble(longitudeInput.getText().toString());

            // Add location to database
            databaseHelper.addLocation(address, latitude, longitude);
            Toast.makeText(this, "Location added", Toast.LENGTH_SHORT).show();
        });
        // Update Button OnClickListener
        updateButton.setOnClickListener(view -> {
            String address = addressInput.getText().toString();
            double latitude = Double.parseDouble(latitudeInput.getText().toString());
            double longitude = Double.parseDouble(longitudeInput.getText().toString());

            // Update location in database
            int rowsAffected = databaseHelper.updateLocation(address, latitude, longitude);
            if (rowsAffected > 0) {
                Toast.makeText(this, "Location updated", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Address not found", Toast.LENGTH_SHORT).show();
            }
        });
        // Delete Button OnClickListener
        deleteButton.setOnClickListener(view -> {
            String address = addressInput.getText().toString();

            // Delete location from database
            databaseHelper.deleteLocation(address);
            Toast.makeText(this, "Location deleted (if existed)", Toast.LENGTH_SHORT).show();
        });
    }
}
